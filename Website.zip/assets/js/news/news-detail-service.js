async function fetchNews(slug) {

  const { data, error } =
    await window.supabaseClient
      .from(window.siteConfig.tables.news)
      .select('*')
      .eq('slug', slug)
      .eq('published', true)
      .single();

  if (error) {

    console.error(error);

    return null;

  }

  return data;

}
